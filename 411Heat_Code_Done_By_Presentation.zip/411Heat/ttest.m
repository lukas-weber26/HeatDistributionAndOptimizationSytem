[M,I] = min(Ts)
As(I,:)